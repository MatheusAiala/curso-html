const Imovel = require('../classes/Imovel');
const GerenciadorImoveis = require('../classes/GerenciadorImoveis');

describe('GerenciadorImoveis', () => {
    let gerenciador;

    beforeEach(() => {
        gerenciador = new GerenciadorImoveis();
        jest.spyOn(gerenciador, 'enviarNotificacao');
    });

    afterEach(() => {
        jest.clearAllMocks();
    });

    const mockBuscarEnderecoPorCEP = jest.fn();

    test('CEP válido: deve adicionar o imóvel e chamar a notificação', async () => {
        mockBuscarEnderecoPorCEP.mockResolvedValue('Servidão estação lua clara, Rio Vermelho - Florianópolis/SC');
        gerenciador.buscarEnderecoPorCEP = mockBuscarEnderecoPorCEP;

        const imovel = new Imovel(1, '88060-387', 'Rio Vermelho', 510000, 'disponível', 800, null);

        await gerenciador.adicionarImovel(imovel);

        expect(gerenciador.imoveis.length).toBe(1);
        expect(gerenciador.imoveis[0]).toBe(imovel);

        expect(gerenciador.enviarNotificacao).toHaveBeenCalledTimes(1);
    });

    test('Erro inesperado na API de CEP: não deve adicionar imóvel e não chamar a notificação', async () => {

        mockBuscarEnderecoPorCEP.mockRejectedValueOnce(new Error('Falha de rede'));
        gerenciador.buscarEnderecoPorCEP = mockBuscarEnderecoPorCEP;

        const imovel = new Imovel(1, '88058992', 'ingleses', 100000, 'disponível', 100, null);

        try {
            await gerenciador.adicionarImovel(imovel);
        } catch (error) {
            expect(gerenciador.imoveis.length).toBe(0);
            expect(gerenciador.enviarNotificacao).toHaveBeenCalledTimes(0);
            expect(error.message).toBe('Endereço não encontrado para o CEP informado.');
        }
    });


    test('API de CEP retorna endereço vazio: não deve adicionar imóvel e não chamar a notificação', async () => {
        mockBuscarEnderecoPorCEP.mockResolvedValueOnce(null);
        gerenciador.buscarEnderecoPorCEP = mockBuscarEnderecoPorCEP;

        const imovel = new Imovel(1, '88058992', 'ingleses', 100000, 'disponível', 100, null);

        try {
            await gerenciador.adicionarImovel(imovel);
        } catch (error) {
            expect(gerenciador.imoveis.length).toBe(0);
            expect(gerenciador.enviarNotificacao).toHaveBeenCalledTimes(0);
            expect(error.message).toBe('Endereço não encontrado para o CEP informado.');
        }
    });

});

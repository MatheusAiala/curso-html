const Imovel = require('../classes/Imovel');
const GerenciadorImoveis = require('../classes/GerenciadorImoveis');

describe('GerenciadorImoveis', () => {
    let gerenciador;

    beforeEach(() => {
        gerenciador = new GerenciadorImoveis();
    });

    // Testes do método adicionarImovel
    test('adiciona um imóvel válido com sucesso', () => {
        const imovel = new Imovel(1, '88060-387', 'Rio Vermelho', 510000, 'disponível', 800, 'Servidão estação lua clara ');
        gerenciador.adicionarImovel(imovel);
        expect(gerenciador.imoveis.length).toBe(1);
        expect(gerenciador.imoveis[0]).toBe(imovel);
    });

    test('falha ao adicionar imóvel com endereço inválido', () => {
        const imovel = new Imovel(2, '88060-387', 'Rio Vermelho', 510000, 'disponível', 800, null);
        expect(() => gerenciador.adicionarImovel(imovel)).toThrow("Endereço inválido.");
    });

    test('falha ao adicionar imóvel com bairro inválido', () => {
        const imovel = new Imovel(3, '88060-387', '', 510000, 'disponível', 800, 'Servidão estação lua escura');
        expect(() => gerenciador.adicionarImovel(imovel)).toThrow("Bairro inválido.");
    });

    test('falha ao adicionar imóvel com preço inválido', () => {
        const imovel = new Imovel(4, '88060-387', 'Rio Vermelho', -100, 'disponível', 800, 'Servidão estação lua rosa');
        expect(() => gerenciador.adicionarImovel(imovel)).toThrow("Preço inválido. Deve ser um número maior que zero.");
    });

    test('falha ao adicionar imóvel com status inválido', () => {
        const imovel = new Imovel(5, '88060-387', 'Rio Vermelho', 510000, 'em análise', 800, 'Servidão estação lua degrade');
        expect(() => gerenciador.adicionarImovel(imovel)).toThrow("Status inválido. Deve ser 'disponível' ou 'indisponível'.");
    });

    // Testes do método buscarImoveisPorBairro
    test('retorna imóveis do bairro especificado', () => {
        gerenciador.adicionarImovel(new Imovel(6, '88060-387', 'Rio Vermelho', 510000, 'disponível', 800, 'Servidão estação lua clara'));
        gerenciador.adicionarImovel(new Imovel(7, '88058-397', 'Ingleses', 830000, 'indisponível', 21, 'Rua Faria adelaide'));
        gerenciador.adicionarImovel(new Imovel(8, '88060-358', 'Rio Vermelho', 135000, 'disponível', 235, 'Rua não lembro'));

        const resultado = gerenciador.buscarImoveisPorBairro('Rio Vermelho');
        expect(resultado.length).toBe(2);
        expect(resultado.every(i => i.bairro === 'Rio Vermelho')).toBe(true);
    });

    test('retorna lista vazia se nenhum imóvel do bairro for encontrado', () => {
        gerenciador.adicionarImovel(new Imovel(9, '58027-344', 'Estreito', 450000, 'disponível', 74, 'Rua H Romeu Mufasa'));

        const resultado = gerenciador.buscarImoveisPorBairro('Rio Vermelho');
        expect(resultado.length).toBe(0);
    });

    // Testes do método listarImoveisDisponiveis
    test('retorna apenas imóveis com status "disponível"', () => {
        gerenciador.adicionarImovel(new Imovel(10, '88060-387', 'Rio Vermelho', 510000, 'disponível', 800, 'ervidão estação lua clara'));
        gerenciador.adicionarImovel(new Imovel(11, '88058-397', 'Ingleses', 830000, 'indisponível', 21, 'Rua Faria adelaide'));

        const disponiveis = gerenciador.listarImoveisDisponiveis();
        expect(disponiveis.length).toBe(1);
        expect(disponiveis[0].status).toBe('disponível');
    });

    test('retorna lista vazia se nenhum imóvel estiver disponível', () => {
        gerenciador.adicionarImovel(new Imovel(12, '88058-397', 'Ingleses', 830000, 'indisponível', 21, 'Rua Faria adelaide'));

        const disponiveis = gerenciador.listarImoveisDisponiveis();
        expect(disponiveis.length).toBe(0);
    });
});
